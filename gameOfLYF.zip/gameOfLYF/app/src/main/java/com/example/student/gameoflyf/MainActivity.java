package com.example.student.gameoflyf;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.GridLayout;

public class MainActivity extends AppCompatActivity {


    GridLayout layout;
    float x = 0;
    float y = 0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        PixelGridView pixelGrid = new PixelGridView(this);
        pixelGrid.setNumColumns(12);
        pixelGrid.setNumRows(12);

        setContentView(pixelGrid);
    }
}
      /*
        layout=(GridLayout)findViewById(R.id.activity_main);
        layout.addView(new CustomView(MainActivity.this));
    }

    public class CustomView extends View {

        Bitmap mBitmap;
        Paint paint;

        public CustomView(Context context) {
            super(context);
            mBitmap = Bitmap.createBitmap(1000, 1000, Bitmap.Config.ARGB_8888);
            paint = new Paint();
            paint.setColor(Color.RED);
            paint.setStyle(Paint.Style.FILL);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            canvas.drawCircle(x, y, 10, paint);
        }

        public boolean onTouchEvent(MotionEvent event) {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                x = event.getX();
                Log.i("X is : ", x+"");
                y = event.getY();

                Log.i("Y is : ", y+"");
                invalidate();
            }
            return false;
        }
    }
}
*/